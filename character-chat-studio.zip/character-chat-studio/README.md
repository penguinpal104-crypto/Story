# Character Chat Studio

A private, local-first character-chat website starter with:
- Create, edit and delete character profiles
- Separate chats for each character
- Edit both user and AI messages
- Persistent SQLite storage for characters, chats and every message
- Searchable chat history
- Cross-chat recall: the server stores all chats and supplies a compact recent-history context plus the current chat to the model
- API key kept on the server, never in browser code

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Add your API key to `OPENAI_API_KEY` in `.env`.
4. In this folder, run:

   ```bash
   npm install
   npm start
   ```

5. Open http://localhost:3000

Without an API key, the site runs in demo mode and returns a sample reply.

## Memory and limits

All messages are saved in `data/character-chat.sqlite`. The model cannot literally process an unlimited lifetime of messages in one prompt. This starter sends the current conversation and a recent cross-chat memory window; the full archive remains stored and searchable in the app. For stronger long-term recall, add a background summarizer or embeddings/vector search.

## Safety and privacy

This project intentionally does not provide a “no safety rules” mode. The server adds a basic safety instruction and the model provider may apply its own policies. Do not use it to bypass safeguards.

This is a single-user local starter, not a hardened public service. Before putting it online, add authentication, HTTPS, rate limiting, abuse prevention, backups, data export/deletion controls and hosting secrets. Never commit `.env` or expose your API key. Use only content and data you have permission to store.
